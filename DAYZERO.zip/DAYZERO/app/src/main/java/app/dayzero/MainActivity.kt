package app.dayzero
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.*
import java.time.*
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

val fmt: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.getDefault())
private val Bg = Color(0xFF08080C); private val CardC = Color(0xFF14141C)
private val Accent = Color(0xFF7C8CFF); private val Dim = Color(0xFF9A9AB0)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { DayZero(Store(this)) } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun DayZero(store: Store) {
    val ctx = LocalContext.current
    var goals by remember { mutableStateOf(store.all()) }
    var editing by remember { mutableStateOf<Goal?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Goal?>(null) }
    fun save(l: List<Goal>) { store.save(l); goals = l; CoroutineScope(Dispatchers.Main).launch { DayWidget().updateAll(ctx) } }
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = CardC, onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            val p = goals.firstOrNull { it.primary } ?: goals.firstOrNull()
            if (p == null) Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center) {
                Text("DAYZERO", color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Spacer(Modifier.height(12.dp))
                Text("What are you counting down to?", fontSize = 34.sp, fontWeight = FontWeight.Bold, lineHeight = 40.sp)
                Spacer(Modifier.height(32.dp))
                Button({ adding = true }, Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) { Text("START COUNTDOWN", fontWeight = FontWeight.Bold) }
            } else LazyColumn(Modifier.fillMaxSize().systemBarsPadding(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Hero(p) }
                item { Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("ALL GOALS", color = Dim, fontSize = 12.sp, letterSpacing = 2.sp)
                    Text("+ ADD", color = Accent, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { adding = true }.padding(4.dp)) } }
                items(goals, key = { it.id }) { g ->
                    val (big, cap) = label(g)
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CardC)) {
                        Column(Modifier.padding(16.dp)) {
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text(g.name, fontWeight = FontWeight.SemiBold, fontSize = 17.sp); Text(g.target.format(fmt), color = Dim, fontSize = 13.sp) }
                                Text("$big ${cap.substringBefore(" ·")}", color = Accent, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                            }
                            Row {
                                TextButton({ save(goals.map { it.copy(primary = it.id == g.id) }) }) { Text(if (g.id == p.id) "★ Widget goal" else "☆ Set primary") }
                                TextButton({ editing = g }) { Text("Edit") }
                                TextButton({ deleting = g }) { Text("Delete", color = Color(0xFFFF6B6B)) }
                            }
                        }
                    }
                }
            }
        }
        if (adding || editing != null) GoalDialog(editing, { adding = false; editing = null }) { g ->
            val first = goals.isEmpty()
            save(if (goals.any { it.id == g.id }) goals.map { if (it.id == g.id) g.copy(primary = it.primary) else it } else goals + g.copy(primary = first))
            adding = false; editing = null
        }
        deleting?.let { d -> AlertDialog(onDismissRequest = { deleting = null }, title = { Text("Delete \"${d.name}\"?") }, text = { Text("This can't be undone.") },
            confirmButton = { TextButton({
                val r = goals.filter { it.id != d.id }
                save(if (r.isNotEmpty() && r.none { it.primary }) listOf(r[0].copy(primary = true)) + r.drop(1) else r); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton({ deleting = null }) { Text("Cancel") } }) }
    }
}

@Composable fun Hero(g: Goal) {
    val d = daysLeft(g); val (big, cap) = label(g)
    val n by animateIntAsState(if (d > 0) d.toInt() else 0, tween(1000, easing = FastOutSlowInEasing), label = "count")
    val glow by rememberInfiniteTransition(label = "g").animateFloat(0.10f, 0.22f, infiniteRepeatable(tween(4000), RepeatMode.Reverse), label = "a")
    val pct = progress(g)
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp))
        .background(Brush.radialGradient(listOf(Accent.copy(alpha = glow), CardC, Bg), radius = 900f))
        .padding(28.dp).semantics(mergeDescendants = true) { contentDescription = "${g.name}: $big $cap" },
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(g.name.uppercase(), color = Dim, letterSpacing = 3.sp, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(if (d > 0) n.toString() else big, fontSize = 112.sp, fontWeight = FontWeight.Black, lineHeight = 120.sp, modifier = Modifier.padding(top = 8.dp))
        Text(cap, color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, fontSize = 14.sp, textAlign = TextAlign.Center)
        Text(g.target.format(fmt).uppercase(), color = Dim, fontSize = 13.sp, modifier = Modifier.padding(top = 16.dp))
        if (g.quote.isNotBlank()) Text("“${g.quote}”", color = Dim, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(24.dp))
        LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)), color = Accent, trackColor = Color(0xFF262633))
        Text("${(pct * 100).toInt()}% · ${ChronoUnit.DAYS.between(g.start, LocalDate.now()).coerceAtLeast(0)} days passed · ${ChronoUnit.DAYS.between(g.start, g.target)} total",
            color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun GoalDialog(edit: Goal?, onDismiss: () -> Unit, onSave: (Goal) -> Unit) {
    var name by remember { mutableStateOf(edit?.name ?: "SSC CGL 2027") }
    var quote by remember { mutableStateOf(edit?.quote ?: "Every day counts.") }
    var date by remember { mutableStateOf(edit?.target ?: LocalDate.of(2027, 7, 15)) }
    var pick by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (edit == null) "New countdown" else "Edit goal") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Goal name") }, singleLine = true)
            OutlinedButton({ pick = true }, Modifier.fillMaxWidth()) { Text("Target: ${date.format(fmt)}") }
            OutlinedTextField(quote, { quote = it }, label = { Text("Quote (optional)") })
        } },
        confirmButton = { TextButton({ if (name.isNotBlank()) onSave(Goal(edit?.id ?: System.currentTimeMillis(), name.trim(), date, edit?.start ?: LocalDate.now(), quote.trim(), false)) }) { Text("START") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
    if (pick) {
        val st = rememberDatePickerState(date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog({ pick = false }, confirmButton = { TextButton({ st.selectedDateMillis?.let { date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() }; pick = false }) { Text("OK") } }) { DatePicker(st) }
    }
}
