package app.dayzero
import android.content.Context
import org.json.*
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Goal(val id: Long, val name: String, val target: LocalDate, val start: LocalDate,
                val quote: String, val primary: Boolean)

/** Days from today to target: >0 future, 0 today, <0 passed. java.time handles leap years / month lengths. */
fun daysLeft(g: Goal, today: LocalDate = LocalDate.now()) = ChronoUnit.DAYS.between(today, g.target)

fun progress(g: Goal, today: LocalDate = LocalDate.now()): Float {
    val total = ChronoUnit.DAYS.between(g.start, g.target).coerceAtLeast(1)
    return (ChronoUnit.DAYS.between(g.start, today).toFloat() / total).coerceIn(0f, 1f)
}
/** (big text, caption) — never a negative number. */
fun label(g: Goal): Pair<String, String> {
    val d = daysLeft(g)
    return when {
        d == 0L -> "0" to "TODAY IS THE DAY"
        d > 0 -> d.toString() to (if (d == 1L) "DAY LEFT" else "DAYS LEFT")
        else -> "✓" to "GOAL COMPLETED · ${-d} DAYS AGO"
    }
}

class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("dayzero", Context.MODE_PRIVATE)
    fun all(): List<Goal> = try {
        val a = JSONArray(sp.getString("goals", "[]"))
        (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
            Goal(o.getLong("id"), o.getString("name"), LocalDate.ofEpochDay(o.getLong("t")),
                LocalDate.ofEpochDay(o.getLong("s")), o.optString("q"), o.optBoolean("p")) } }
    } catch (e: Exception) { emptyList() }
    fun save(l: List<Goal>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("t", it.target.toEpochDay())
            .put("s", it.start.toEpochDay()).put("q", it.quote).put("p", it.primary)) }
        sp.edit().putString("goals", a.toString()).apply()
    }
    fun primary() = all().let { l -> l.firstOrNull { it.primary } ?: l.firstOrNull() }
}
