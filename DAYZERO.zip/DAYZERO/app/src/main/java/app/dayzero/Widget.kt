package app.dayzero
import android.content.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.*
import androidx.glance.*
import androidx.glance.action.clickable
import androidx.glance.appwidget.*
import androidx.glance.layout.*
import androidx.glance.text.*
import kotlinx.coroutines.*

private val Accent = Color(0xFF7C8CFF)
private val Dim = Color(0xFF9A9AB0)
class DayWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val g = Store(context).primary()
        provideContent {
            val small = LocalSize.current.height < 130.dp
            Column(GlanceModifier.fillMaxSize().appWidgetBackground().background(ImageProvider(R.drawable.widget_bg))
                .padding(12.dp).clickable(actionStartActivity<MainActivity>()),
                verticalAlignment = Alignment.CenterVertically, horizontalAlignment = Alignment.CenterHorizontally) {
                if (g == null) Text("Open DAYZERO to start", style = TextStyle(color = ColorProvider(Color.White)))
                else {
                    val (big, cap) = label(g)
                    Text(g.name.uppercase(), maxLines = 1, style = TextStyle(color = ColorProvider(Dim), fontSize = 11.sp, fontWeight = FontWeight.Medium))
                    Text(big, style = TextStyle(color = ColorProvider(Color.White), fontSize = if (small) 44.sp else 64.sp, fontWeight = FontWeight.Bold))
                    Text(cap, style = TextStyle(color = ColorProvider(Accent), fontSize = 11.sp, fontWeight = FontWeight.Bold))
                    if (!small) Text(g.target.format(fmt).uppercase(), modifier = GlanceModifier.padding(top = 8.dp),
                        style = TextStyle(color = ColorProvider(Dim), fontSize = 11.sp))
                }
            }
        }
    }
}
class WidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget: GlanceAppWidget = DayWidget() }

/** Fires on date change, time/timezone change and reboot so the widget never shows a stale count. */
class DayChangeReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = goAsync()
        CoroutineScope(Dispatchers.Default).launch { try { DayWidget().updateAll(c) } finally { p.finish() } }
    }
}
